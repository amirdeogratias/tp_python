"""
main.py - Point d'entrée de l'application SahelSound Records
Menu principal et sous-menus pour gérer le catalogue musical.
"""

import sys
from label import (
    charger_catalogue,
    sauvegarder_catalogue,
    lister_artistes,
    rechercher_artiste,
    ajouter_artiste,
    ajouter_album,
    afficher_detail_artiste,
)
from analyse import afficher_stats, exporter_rapport

CHEMIN_JSON = "catalogue.json"
CHEMIN_CSV = "rapport.csv"

SEPARATEUR = "=" * 55


def afficher_menu_principal():
    """Affiche le menu principal de l'application."""
    print("\n" + SEPARATEUR)
    print("       🎵 SAHELSOUND RECORDS — CATALOGUE 🎵")
    print(SEPARATEUR)
    print("  1. Consulter le catalogue")
    print("  2. Ajouter un artiste")
    print("  3. Ajouter un album à un artiste existant")
    print("  4. Statistiques et rapport")
    print("  5. Quitter")
    print(SEPARATEUR)


def sous_menu_consulter(catalogue):
    """
    Sous-menu pour consulter le catalogue.

    Args:
        catalogue (list): Catalogue chargé en mémoire
    """
    print("\n--- Consulter le catalogue ---")
    print("  a. Afficher tous les artistes")
    print("  b. Rechercher par nom ou genre")
    print("  c. Détail d'un artiste")
    choix = input("Votre choix : ").strip().lower()

    if choix == "a":
        artistes = lister_artistes(catalogue)
        if not artistes:
            print("Le catalogue est vide.")
            return
        print(f"\n{'ID':<10} {'Nom':<25} {'Genre':<20} {'Pays':<15} {'Albums'}")
        print("-" * 80)
        for a in artistes:
            print(f"{a['id']:<10} {a['nom']:<25} {a['genre']:<20} {a['pays']:<15} {a['nb_albums']}")

    elif choix == "b":
        critere = input("Rechercher par (nom / genre) : ").strip().lower()
        if critere not in ("nom", "genre"):
            print("Critère invalide. Choisissez 'nom' ou 'genre'.")
            return
        valeur = input(f"Valeur de recherche pour '{critere}' : ").strip()
        resultats = rechercher_artiste(catalogue, critere, valeur)
        if not resultats:
            print("Aucun artiste trouvé.")
        else:
            print(f"\n{len(resultats)} résultat(s) :")
            for a in resultats:
                print(f"  [{a['id']}] {a['nom']} — {a['genre']} ({a['pays']})")

    elif choix == "c":
        id_ou_nom = input("Entrez l'ID ou le nom de l'artiste : ").strip()
        artiste = afficher_detail_artiste(catalogue, id_ou_nom)
        if not artiste:
            print("Artiste introuvable.")
            return
        print(f"\n{'='*40}")
        print(f"  {artiste['nom']}  [{artiste['id']}]")
        print(f"  Genre : {artiste['genre']}  |  Pays : {artiste['pays']}")
        print(f"  {'-'*38}")
        albums = artiste.get("albums", [])
        if not albums:
            print("  Aucun album enregistré.")
        else:
            print(f"  {'Titre':<30} {'Année':<8} {'Streams':>12}")
            print(f"  {'-'*52}")
            for alb in albums:
                print(f"  {alb['titre']:<30} {alb['annee']:<8} {alb['streams']:>12,}")
        print(f"{'='*40}")
    else:
        print("Choix invalide.")


def sous_menu_ajouter_artiste(catalogue):
    """
    Sous-menu pour saisir et ajouter un nouvel artiste.

    Args:
        catalogue (list): Catalogue chargé en mémoire

    Returns:
        list: Catalogue mis à jour
    """
    print("\n--- Ajouter un artiste ---")
    try:
        id_artiste = input("ID de l'artiste (ex: ART-013) : ").strip().upper()
        nom = input("Nom de scène : ").strip()
        genre = input("Genre musical : ").strip()
        pays = input("Pays d'origine : ").strip()

        nouvel_artiste = {
            "id": id_artiste,
            "nom": nom,
            "genre": genre,
            "pays": pays,
            "albums": [],
        }
        catalogue = ajouter_artiste(catalogue, nouvel_artiste)
        sauvegarder_catalogue(catalogue, CHEMIN_JSON)
        print(f"✔ Artiste '{nom}' ajouté et catalogue sauvegardé.")
    except ValueError as e:
        print(f"Erreur : {e}")

    return catalogue


def sous_menu_ajouter_album(catalogue):
    """
    Sous-menu pour ajouter un album à un artiste existant.

    Args:
        catalogue (list): Catalogue chargé en mémoire

    Returns:
        list: Catalogue mis à jour
    """
    print("\n--- Ajouter un album ---")
    try:
        id_artiste = input("ID de l'artiste cible : ").strip().upper()
        titre = input("Titre de l'album : ").strip()
        annee = input("Année de sortie : ").strip()
        streams = input("Nombre de streams : ").strip()

        album = {"titre": titre, "annee": annee, "streams": streams}
        catalogue = ajouter_album(catalogue, id_artiste, album)
        sauvegarder_catalogue(catalogue, CHEMIN_JSON)
        print(f"✔ Album '{titre}' ajouté à l'artiste {id_artiste} et catalogue sauvegardé.")
    except ValueError as e:
        print(f"Erreur : {e}")

    return catalogue


def sous_menu_statistiques():
    """Sous-menu pour afficher les statistiques et exporter le rapport."""
    print("\n--- Statistiques et rapport ---")
    print("  a. Afficher toutes les statistiques")
    print("  b. Exporter le rapport en CSV")
    choix = input("Votre choix : ").strip().lower()

    if choix == "a":
        try:
            afficher_stats(CHEMIN_JSON)
        except Exception as e:
            print(f"Erreur lors de l'analyse : {e}")

    elif choix == "b":
        try:
            message = exporter_rapport(CHEMIN_JSON, CHEMIN_CSV)
            print(f"✔ {message}")
        except Exception as e:
            print(f"Erreur lors de l'export : {e}")
    else:
        print("Choix invalide.")


def main():
    """Boucle principale de l'application SahelSound Records."""
    print("\nBienvenue sur SahelSound Records — Gestion du catalogue musical")

    try:
        catalogue = charger_catalogue(CHEMIN_JSON)
    except FileNotFoundError:
        print(f"Fichier '{CHEMIN_JSON}' introuvable. Démarrage avec un catalogue vide.")
        catalogue = []
    except Exception as e:
        print(f"Erreur au chargement du catalogue : {e}")
        sys.exit(1)

    while True:
        afficher_menu_principal()
        choix = input("Votre choix (1-5) : ").strip()

        if choix == "1":
            sous_menu_consulter(catalogue)

        elif choix == "2":
            catalogue = sous_menu_ajouter_artiste(catalogue)

        elif choix == "3":
            catalogue = sous_menu_ajouter_album(catalogue)

        elif choix == "4":
            sous_menu_statistiques()

        elif choix == "5":
            print("\nMerci d'avoir utilisé SahelSound Records. À bientôt !")
            break

        else:
            print("Choix invalide. Entrez un nombre entre 1 et 5.")


if __name__ == "__main__":
    main()
